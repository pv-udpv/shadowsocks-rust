//! SOCKS 4/4a clients

pub use self::tcp_client::Socks4TcpClient;

mod tcp_client;
